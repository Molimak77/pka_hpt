# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pka_hpt']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pka-hpt',
    'version': '0.1.0',
    'description': 'Python package test build with poetry and hosted in github',
    'long_description': '# pka_hpt\ntest the package build with poetry and hosted to github \n',
    'author': 'molierenguile-makao',
    'author_email': 'moliere.nguile@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Molimak77/pka_hpt',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
